# BBTools bioinformatics tools, including BBMap.
# Author: Brian Bushnell, Jon Rood, Shijie Yao, Jasper Toscani Field
# Language: Java, Bash
# Information about documentation is in /docs/readme.txt.

# Version 38.96
