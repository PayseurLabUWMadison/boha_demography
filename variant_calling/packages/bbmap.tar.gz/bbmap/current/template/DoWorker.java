package template;

public interface DoWorker {
	
	public void doWork();
	
}
