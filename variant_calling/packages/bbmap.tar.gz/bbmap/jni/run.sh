#!/bin/bash
rm I*.o *.so ; make -f makefile.linux
